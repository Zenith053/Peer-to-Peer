

#include <iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <cstring>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include "ls.h"
#include "pinfo.h"
#include "search.h"
#include "ioredirect.h"
#include "handle_pipe.h"
#include "parse.h"
#include <signal.h>
#include "autocomplete.h"
#include "auto_dir.h"
#define HISTORY_FILE "history.txt"

using namespace std;

extern vector<string> autocomplete_words;
struct termios oldt;
char pivot_dir[100] = "/home/cypher/Aos_bash";
int foreground_pid = -1;
string home_address = "/home/cypher/Aos_bash";
// void handle_redirect();

void print_basics(){
    char buff[30];
    // char username[30];
    gethostname(buff,30);
    char *username = getenv("USER");
    struct utsname name;
    uname(&name);   
    string sysname = name.sysname;
    char working_dir[100];
    // working_dir.resize(PATH_MAX);
    getcwd(working_dir,100);
    int start = strlen(pivot_dir);
    string rel_dir;
    for(int i=start;i< strlen(working_dir);i++){
        rel_dir+= working_dir[i];
    }
    cout << username << "@" <<buff << sysname  << rel_dir<< "$" <<  " ~" << " ";
    fflush(NULL);
}

 vector<string> load_history() {
    vector<string> hist;
    FILE *file = fopen(HISTORY_FILE, "r");
    if (!file) return hist;

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file)) {
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0'; // strip newline
        }
        hist.push_back(buffer);
    }
    fclose(file);
    return hist;
}

void save_history(const string &cmd) {
    FILE *file = fopen(HISTORY_FILE, "a"); // append mode
    if (!file) return;
    fprintf(file, "%s\n", cmd.c_str());
    fclose(file);
}
vector<int > b_process;
void handle_sigint(int sig) {
    if (foreground_pid > 0) {
        kill(foreground_pid, SIGINT);   

        // kill(foreground_pid, SIGCONT);
        // forward Ctrl+C to child
    }
}

void handle_sigtstp(int sig) {
    if (foreground_pid > 0) {
        // cout << "reachdeddd here" << endl;
        cout << foreground_pid << endl;
        b_process.push_back(foreground_pid);
        kill(foreground_pid, SIGTSTP);  
        // kill(b_process.back(), SIGCONT);
        // forward Ctrl+Z to child
        // Optionally: store in background jobs list
    }
}
void sigchld_handler(int signal)
{
    int pid;
    int status;
    while ( (pid = waitpid(-1, &status,WNOHANG)) > 0){
        // cout << "The child with pid" << pid << " is being terminataed" << endl;
    }
    return;
    
}

vector<char*> tokenise(string &s) {
    vector<char*> args;
    // string temp = s;
    char* start = &s[0];
    char *token = strtok(start, " ");
    while(token != nullptr){
        // cout << token << endl;   // this is why you see the 2nd "ls" printed
        if (strlen(token) > 0) {       // skip empty tokens
            args.push_back(token);
        }
        token = strtok(nullptr, " ");
    }
    args.push_back(nullptr); // sentinel for execvp
    return args;
}

vector<string> history;
int history_index = -1;
int cursor_pos = 0;

void restore_terminal() {
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
}
int main(){
    struct termios newt;
    signal(SIGINT, handle_sigint);   // Ctrl+C
    signal(SIGTSTP, handle_sigtstp); // Ctrl+Z
    // signal(SIGCHLD, sigchld_handler);  
    //Save current terminal settings
    tcgetattr(STDIN_FILENO, &oldt);
    //-------------
    history = load_history();
    history_index = history.size();


    //--------------
    newt = oldt;
    atexit(restore_terminal);
    // 2. Disable canonical mode and echo
    newt.c_lflag &= ~(ICANON| ECHO);
    // newt.c_iflag &= ~(IXON | ICRNL);   
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    getcwd(pivot_dir,PATH_MAX);
    autocomplete_words.push_back("pinfo");
    auto_complete_list();
    
    // autocomplete_words.push_back("")
    while(1){
        print_basics();
        // memset(args,0,100);
        // getline(cin,s);
        cursor_pos = 0;
        char *c = new char;
        string s;
        while(read(0,c,1)){
            // cout << endl;
            // int n = read(0,c,1);
            // if(n == 0){
            //     cout << "exiting shell" << endl;
            //     exit(0);
            // }
            if(*c == 4){
                cout << "exiting terminal" << endl;
                exit(0);
            }
            else if (*c == '\n') {
                cout << endl;
                if (!s.empty()) {
                    // avoid saving consecutive duplicates
                    if (history.empty() || history.back() != s) {
                        history.push_back(s);
                        save_history(s);
                    }
                    history_index = history.size();
                }
                break;
            }
            else if (*c == '\033') {
                char seq[2];
                read(STDIN_FILENO, &seq[0], 1);
                read(STDIN_FILENO, &seq[1], 1);

                if (seq[0] == '[') {
                    switch (seq[1]) {
                        case 'A': // Up arrow
                            if (!history.empty() && history_index > 0) {
                                history_index--;
                                s = history[history_index];
                                cout << "\033[2K\r"; // clear line
                                print_basics();
                                cout << s << flush;
                                cursor_pos = s.size();
                            }
                            break;

                        case 'B': // Down arrow
                            if (!history.empty() && history_index < (int)history.size() - 1) {
                                history_index++;
                                s = history[history_index];
                            } else {
                                s.clear();
                                history_index = history.size();
                            }
                            cout << "\033[2K\r"; 
                            print_basics();
                            cout << s << flush;
                            cursor_pos = s.size();
                            break;

                        case 'C': // Right arrow
                            if (cursor_pos < (int)s.size()) {
                                cout << "\033[C" << flush;
                                cursor_pos++;
                            }
                            break;

                        case 'D': // Left arrow
                            if (cursor_pos > 0) {
                                cout << "\033[D" << flush;
                                cursor_pos--;
                            }
                            break;
                    }
                }
            }

            else if (*c == '\t') {
                auto_dir();  

                // find last word in s
                size_t pos = s.find_last_of(' ');
                string prefix = (pos == string::npos) ? "" : s.substr(0, pos + 1);
                string lastWord = (pos == string::npos) ? s : s.substr(pos + 1);

                // search matches for last word
                string str1 = string_search(autocomplete_words, lastWord);
                string str2 = search_dir(dir_words, lastWord);

                if (!str2.empty()) s = prefix + str2;
                else if (!str1.empty()) s = prefix + str1;

                cout << "\033[2K\r"; 
                print_basics();
                cursor_pos = s.size();   // always reset cursor to end
                cout << s << flush;
            }
            else if (*c == 127) {  // Backspace
                if (cursor_pos > 0 && s.size() > 0) {
                    s.erase(cursor_pos - 1, 1);
                    cursor_pos--;

                    // move cursor back
                    cout << "\b";

                    // print the rest of the string after deletion
                    cout << s.substr(cursor_pos);

                    // print one extra space to erase last leftover char
                    cout << " ";

                    // move cursor back to the right place
                    int moves = s.size() - cursor_pos + 1;
                    for (int i = 0; i < moves; i++) cout << "\b";

                    cout.flush();
                }
            }

            else{ 
                cout << *c ;    
                cursor_pos++;
                fflush(0);
                s+= *c;
            }
        }
        
        vector<string> commands;
        string temp;
        for(int i=0;i<s.size();i++){
            if(s[i] == ';'){
                cout << temp << endl;
                commands.push_back(temp);
                temp.clear();
            }   
            else temp+= s[i];
        }
        commands.push_back(temp);
        for(int i=0;i<commands.size();i++){
            vector<char*> args = tokenise(commands[i]);
            parse(args);
            args.clear();
        }
        // cout << endl << flush;
        // cout << flush;
        // args
        // cout << s << endl;

        // free(args);
        // dup2(1,stdout)
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
}