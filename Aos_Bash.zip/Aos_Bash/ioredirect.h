#ifndef IO_DIRECT
#define IO_DIRECT
#include<iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <cstring>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include "handle_other.h"
#include "handle_echo.h"
#include "parse.h"

using namespace std;

void parse(vector<char*> &args);

void handle_redirect(vector<char*> &args){
    int stdout_original = dup(STDOUT_FILENO);
    int stdin_original = dup(STDIN_FILENO);
    bool append = false,output = false,input = false;
    string temp(args[0]);
    int input_index,append_index,output_index;
    string input_file,output_file;
    for(int i = 0;i<args.size();i++){ //-1 cause last is null pointer
        if(args[i] == nullptr)continue;
        string curr(args[i]);
        //cout << "tokens are " << curr << endl;
        // string curr_prev(args[i-1]);
        if(curr == ">>"){
            append = true;
            append_index = i;
            args[i] = nullptr;
        }
        else if(curr == ">"){
            output = true;
            output_index = i;
            args[i] = nullptr;
        }
        else if(curr == "<"){
            input_index = i;
            input = true;
            args[i] = nullptr;
        }

    }
    // //cout << "hell" << endl;
    // for(int i=0;i<args.size();i++){
    //     //cout << "final tokes are" << args[i] << endl;
    // }
    //now we also have bool for append output and input
    // now the current file will print to the fd used by stdout fileno
    // int pid = fork();
    // if(pid == 0){
        if(input){
            
            if(args[input_index+1] == nullptr || input_index+1 > args.size()-1){
                perror("invalid syntax");
                return;
            }
            string input_file(args[input_index+1]);
            if(input_file == ">" || input_file == "<<" || input_file == ">" ){
                perror("invalid syntax");
                return;
            }else{
                //we need to redirect our input to somefile name inputfile
                int fd = open(&input_file[0],O_RDONLY);
                if(fd<0){
                    perror("error opening input file");
                }
                else{
                    dup2(fd,0);
                    close(fd);
                    args[input_index+1] = nullptr;
                    //now that we have redirected our input 
                }
            }
        }
        if(append){
            if(append_index+1 > args.size() || args[append_index+1] == nullptr){
                perror("invalid syntax");
                return;
            }
            string input_file(args[append_index+1]);
            if(input_file == ">" || input_file == "<<" || input_file == ">" ){
                perror("invalid syntax");
                return;
            }
            else{
                int fd = open(&input_file[0], O_WRONLY | O_CREAT | O_APPEND, 0644);
                dup2(fd,1);
                close(fd);
                args[append_index+1] = nullptr;
            }
        }
        if(output){
            //cout << "reached right output stream" << endl;
            if(output_index+1 > args.size() || args[output_index+1] == nullptr){
                perror("invalid syntax");
                return;
            }
            string input_file(args[output_index+1]);
            //cout << input_file << endl;
            if(input_file == ">" || input_file == "<<" || input_file == ">" ){
                perror("invalid syntax");
                return;
            }
            else{
                int fd = open(&input_file[0], O_WRONLY | O_CREAT | O_TRUNC, 0644);
                dup2(fd,1);
                close(fd);
                args[output_index+1] = nullptr;
            }
        }
        // int handle_pipe = 1;
        // if(handle_pipe == 1){
        //     return;
        // }
        parse(args);
    // }
    
    // handle_other(args);
    dup2(stdout_original,STDOUT_FILENO);
    dup2(stdin_original, STDIN_FILENO);
}
#endif