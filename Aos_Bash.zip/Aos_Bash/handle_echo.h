
#ifndef H_ECHO
#define H_ECHO
#include<iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <string>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include <sstream>
// #include <fstream>

using namespace std;

void handle_echo(vector<char* > &args){
    // string cmd;
    int i = 0;
    for(int i=1;i<args.size();i++){
        if(args[i] == nullptr)continue;
        string cmd(args[i]);
        cout << cmd << endl;

    }
    return;

}
#endif 