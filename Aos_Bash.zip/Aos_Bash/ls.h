#ifndef H_LS
#define H_LS
#include <iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <cstring>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>

#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <ctime>
#include <iomanip>
using namespace std;

void handle_long_format(const char* path, const char* name) {
    //output using LLM
    struct stat st;
    std::string fullPath = std::string(path) + "/" + name;

    if (stat(fullPath.c_str(), &st) == -1) {
        // perror("stat");
        return;
    }

    // file type + permissions
    cout << ((S_ISDIR(st.st_mode)) ? 'd' : '-') ;
    cout << ((st.st_mode & S_IRUSR) ? 'r' : '-');
    cout << ((st.st_mode & S_IWUSR) ? 'w' : '-');
    cout << ((st.st_mode & S_IXUSR) ? 'x' : '-');
    cout << ((st.st_mode & S_IRGRP) ? 'r' : '-');
    cout << ((st.st_mode & S_IWGRP) ? 'w' : '-');
    cout << ((st.st_mode & S_IXGRP) ? 'x' : '-');
    cout << ((st.st_mode & S_IROTH) ? 'r' : '-');
    cout << ((st.st_mode & S_IWOTH) ? 'w' : '-');
    cout << ((st.st_mode & S_IXOTH) ? 'x' : '-');

    // links, owner, group, size
    cout << " " << st.st_nlink;
    cout << " " << getpwuid(st.st_uid)->pw_name;
    cout << " " << getgrgid(st.st_gid)->gr_name;
    cout << " " << st.st_size;

    // time
    char timebuf[80];
    strftime(timebuf, sizeof(timebuf), "%b %d %H:%M", localtime(&st.st_mtime));
    cout << " " << timebuf;

    // filename
    cout << " " << name << endl;
    // cout << fflush << endl;
}


void handle_ls(vector<char*> &args){
    //we know that args[0] = ls
    bool long_format = false;
    bool show_hidden = false;
    string target_dir = ".";
    for(int i=1;args[i]!= nullptr;i++){
        //can also be handled by getopt
        string cmd(args[i]);
        if(cmd[0] == '-'){
            bool check = false;
            for(int j=1;j<cmd.size();j++){
                if(cmd[j] == 'l'){
                    long_format = true;
                }
                if(cmd[j] == 'a'){
                    show_hidden = true;
                }
                
            }
        }
        else{
            target_dir = cmd;
            if(cmd[0] == '~'){
                target_dir = getenv("HOME");
            }
            
        }
        
    }        
    DIR* dir = opendir(&target_dir[0]);
    if(!dir){
        perror("cannot find dir");
    }
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        string name(entry->d_name);
        
        // if hidden (starts with .) and -a not set, skip
        if (!show_hidden && name[0] == '.')continue;

        if (long_format) {
            handle_long_format(target_dir.c_str(), entry->d_name);
        } 
        else {
            cout << name << "  "  << endl << flush;
        }
    }      
    cout.flush();
}
#endif
