#ifndef PARSE_H
#define PARSE_H

#include <iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <cstring>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include "ls.h"
#include "pinfo.h"
#include "search.h"
#include "ioredirect.h"
#include "handle_pipe.h"
#include "auto_dir.h"

using namespace std;

extern int foreground_pid;
extern vector<string> dir_words;
extern string home_address;
void sigchld_handler(int signal);
//     int pid;
//     int status;
//     while ( (pid = waitpid(-1, &status,WNOHANG)) > 0){
//         // //cout << "The child with pid" << pid << " is being terminataed" << endl;
//     }
//     return;
    
// }

void handle_redirect(vector<char*> &args);
void handle_pipe(vector<char*> &args);

void parse(vector<char*> &args){
    // string cmd(args[0]);
    //when you call stirng () then it reads till it hits \0
    if(args.size() == 0)return;
    int i=0;
    vector<string> vec;
    bool process = false;
    bool iohandling = false;
    bool handlepipe = false;
    //now i have to do it such a way that & and redirection gets priority 
    
    while(args[i] != NULL){
        string temp(args[i]);
        if(temp == "&"){
            process = true;
            args[i] = nullptr;
        }
        else if(temp == ">" || temp == "<" || temp == ">>"){
            iohandling = true;
            //cout << "caught" << endl;
        }
        else if(temp == "|"){
            //cout << "ibecame true" << endl;
            handlepipe = true;
        }
        else vec.push_back(temp);
        // //cout << "reached here" << temp << endl;
        i++;
    }
    if(vec.size() == 0)return;
        // cout << process << endl;
        // cout << vec[0] << endl;
    
    string cmd = vec[0];
    // //cout << "i am here" << cmd << endl;
    if(cmd == "exit"){
        exit(0);
    }
    else if(cmd == "cd"){
        // cout << << endl;
        // string home;
        bool flag = 0;
        if(args[1] != nullptr ){
            string temp(args[1]);
            if(temp == "~")flag = 1;
        }  
        
        if(args[1] == nullptr || flag == 1){
            args[1] = &home_address[0];
        }
        if(chdir(args[1]) != 0){
            perror("\nError in cd ");
            return;
        }
        else{
            //cout << '\n' << endl;   
        }
        dir_words.clear();
        fflush(NULL);
        
    }
    else if(handlepipe){
        //cout << "reachy here2" << endl;
        handle_pipe(args);
    }
    else if(iohandling){
        
        string filename(args[1]); //we need to change it
        // int newfd = open(&filename[0],O_WRONLY | O_CREAT | O_TRUNC, 0644);
        handle_redirect(args);
    }
    else if(cmd == "echo"){
        // //cout << "reached echo" << endl;
        // //cout << endl;   
        int i =1;
        while(args[i] != nullptr){
            // //cout << endl;
            string cmd(args[i]);
            cmd+= " ";
            write(STDOUT_FILENO, &cmd[0], cmd.size());
            // //cout << cmd << flush;
            i++;
        }
        cout << endl;
    }   
    else if(cmd == "ls"){
        // cout << endl;   
        handle_ls(args);
        //cout << endl;
    }
    else if(process){
        //cout << endl;   
        // //cout << "did i reach here" << endl;
        signal(SIGCHLD,sigchld_handler);
        int pid = fork();
        
        if(pid == 0){
            //we need to execute the command in background
            execvp(args[0],&args[0]);
            perror("execvp failed");
            _exit(1);
        }
        else{
            cout << pid << endl;
        }
    }
    else if(cmd == "pinfo"){

        // cout << endl;
        handle_pinfo(args);
    }
    else if(cmd == "pwd"){
        char cwd[PATH_MAX];
        getcwd(cwd,sizeof(cwd));
        cout << cwd << endl;
    }
    else if(cmd == "search"){
        // //cout << "reached" << endl
        //cout << endl;   
        char address[100];
        getcwd(address,100);
        string filename(args[1]);
        string output(&address[0]);
        if(search(filename,output)){
            cout << "true" << endl << flush;
        }
        else cout << "false" << endl <<flush;
    }
    else if(cmd == "histroy"){
        
    }
    else{
        // cout << "reached here" << endl;
        int pid = fork();
        
        if(pid == 0){
            //it's a child process 
            int i = 0;
            execvp(args[0], args.data());
            perror("execvp failed");
            _exit(1);

        }
        else {
            foreground_pid = pid;
            int status;
            waitpid(pid, &status, WUNTRACED);
            foreground_pid = -1;
            cout << endl;
        }
        
        
    }

}
#endif // PARSE_H
