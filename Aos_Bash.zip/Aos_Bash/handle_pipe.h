#ifndef H_PIPE
#define H_PIPE

#include <iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <string>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include <sstream>
#include "parse.h"
// #include "ioredirect.h"

using namespace std;

void parse(vector<char*> &args);

void handle_pipe(vector<char*> &args){
    // cout << "reached here and there" << endl;
    //first we need tokenise 
    // cout << "makkicut" << endl;
    vector<vector<char*>> vec;
    vector<char*> temp;
    vector<int> pids;
    for(int i=0;i<args.size();i++){
        //all we need to do is to 
        
        if(args[i] == nullptr)continue;
        string cmd(args[i]);
        if(cmd == "|"){
            // need to push it to temp
            temp.push_back(nullptr);
            vec.push_back(temp);
            //ree temp;
            temp.clear(); // it might create porblem as clear does not resize();
        }
        else temp.push_back(args[i]);
        
    }
    temp.push_back(nullptr);
    vec.push_back(temp);

    //we are done with tokenisatoin and splitting
    //--------------------------------------------------

    for(int i=0;i<vec.size();i++){
        for(int j=0;j<vec[i].size();j++){
            // cout << vec[i][j] << " ";
        }
        cout << endl;
    }

    //--------------------------------------------------
    //now we create n-1 pipes 
    int n = vec.size();
    int pipes[n-1][2];
    for(int i=0;i<n-1;i++){
        pipe(pipes[i]);
        // cout << pipes[i][0] << endl;
        // cout << pipes[i][1] << endl;
    }
    //now that we have created n-1 pipes what to do now
    for(int i=0;i<n;i++){
        int pid = fork();
        if(pid == 0){

            bool flag = false;
            //we need to make pipe connections
            if(i>0){
                dup2(pipes[i-1][0],STDIN_FILENO);

            }
            if(i<n-1){
                dup2(pipes[i][1],STDOUT_FILENO);
            }

                //first child
            // }
            for (int j=0; j<n-1; j++) {
                // int term_fd = open("/dev/tty", O_WRONLY);
                // dprintf(term_fd, "child %d stdout %d stdin %d\n", i, pipes[i][1], pipes[i][0]);
                // close(term_fd); 
                close(pipes[j][0]); //its the standard way
                close(pipes[j][1]);
            }
            // cout << "hhhheeereee" << endl;
            parse(vec[i]);
            // execvp(vec[i][0], vec[i].data());
            // perror("execvp");-
            _exit(1);
        }
        else{
            pids.push_back(pid);
        }
    }
    
    for (int j = 0; j < n - 1; j++) {
        close(pipes[j][0]);
        close(pipes[j][1]);
    }

    for(int pid : pids){
        waitpid(pid,nullptr,0);
    }
}

#endif