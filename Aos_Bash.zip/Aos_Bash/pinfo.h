#ifndef PINFO
#define PINFO
#include<iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <string>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include <sstream>
#include <fstream>

using namespace std;

void handle_pinfo(vector<char*>argv){
    int pid = 0;
    if(argv[1] == nullptr){
        pid = getpid();
    }
    else{
        string temp_pid(argv[1]);
        pid = stoi(temp_pid);
    }
    string string_pid = to_string(pid);
    ifstream stat_file("/proc/" + string_pid + "/stat");
    if (!stat_file) {
        cout << "Error: Could not open /proc/" << pid << "/stat" << std::endl;
        return;
    }
    std::string pid_read, comm, state;
    int ppid, pgrp, session, tty_nr;
    stat_file >> pid_read >> comm >> state >> ppid >> pgrp >> session >> tty_nr;
    //we are taking all these input because it contains a varity of information

    string status_display = state;

    // Check if process is in foreground (tty_nr != 0)
    if (tty_nr != 0)
        status_display += "+";
    cout << pid << " " << status_display << endl;
    string statm_path = string("/proc/") + string_pid + string("/statm");
    ifstream statm_file(statm_path);
    if(statm_file){
        long memory;
        statm_file >> memory;
        cout << "Memory " << memory << " {virtual Memory}" << endl;
    }
    else cout << "Error: something went wrong" << endl;

    char exe_path[PATH_MAX];
    string exe_link = "/proc/" + string_pid + "/exe";
    ssize_t len = readlink(exe_link.c_str(), exe_path, sizeof(exe_path) - 1);
    //we use readlink because it contains a link rather than a file which we can read normally
    // the link contain the path
    // string exe_realpath;
    if(len != -1){
        string exe_realpath(exe_path);
        cout << exe_realpath << endl << flush;
    }
    else{
        cout << "read nothing" << endl << flush;
    }
    //now we have the integer pid
    
}

#endif