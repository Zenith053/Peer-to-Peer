#ifndef SEARCH
#define SEARCH
#include<iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <string>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include <sstream>
// #include <fstream>
#include <sys/stat.h>
#include <dirent.h>

using namespace std;

bool search(const string& s, const string& path) {
    // cout << "i am here" << endl;
    DIR* dir = opendir(path.c_str());
    if (!dir) {
        cerr << "cannot open dir: " << path << endl;
        return false;
    }

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        string name(entry->d_name);
        // other wise it will continue to reucrse in same dir
        if (name == "." || name == "..") continue;

        string new_full_path = path + "/" + name;
        // cout << name << endl;
        if (name == s) {
            // cout << "true " << endl;
            closedir(dir);
            return true;
        }

        struct stat st;
        if (stat(new_full_path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) {
            //for checking if it's a directory or not
            if (search(s, new_full_path)) {
                //searching in the new file
                closedir(dir);
                return true;
            }
        }
        // else return false;
    }

    closedir(dir);
    return false;
}
#endif