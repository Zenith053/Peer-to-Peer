#ifndef HANDLE_OTHER
#define HANDLE_OTHER

#include<iostream>
#include <sys/utsname.h>
#include <unistd.h>
#include <termios.h>
#include <string>
#include <limits.h>
#include <fcntl.h>
#include <vector>
#include <sys/wait.h>
#include <sstream>
#include "parse.h"
// #include <fstream>

using namespace std;

void handle_other(vector<char*> args){
    // cout << "reached hanlder func" << endl;
    int pid = fork();
    if(pid == 0){
        //it's a child process 
        int i = 0;
        
        execvp(args[0], args.data());
        perror("execvp failed");
        exit(1);

        
        
    }
    else {
        // cout << endl;
        wait(nullptr);

        // exit(2);
    }
    
    return;
}
#endif