#ifndef AUTO_COMPLETE
#define AUTO_COMPLETE
#include <iostream>
#include <sys/utsname.h>
#include <cstring>
#include <vector>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <algorithm>

using namespace std;

vector<string> autocomplete_words;
using namespace std;

bool match_prefix(string a,string target){
    if(a.size() < target.size())return false;
    for(int i=0;i<target.size();i++){
        if(a[i] == target[i])continue;
        else return false;
    }
    return true;
}
string string_search(vector<string>autocomplete_words,string target){
    for(int i=0;i<autocomplete_words.size();i++){
        if(match_prefix(autocomplete_words[i],target))return autocomplete_words[i];
    }
    return "";
}
// i need to open the path file 
void auto_complete_list(){
    DIR* dir = opendir("/usr/bin");
    if(!dir){
        perror("cannot find dir");
    }
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        string name(entry->d_name);
        
        // if hidden (starts with .) and -a not set, skip
        if (name[0] == '.')continue;

        autocomplete_words.push_back(name);
    }      
    sort(autocomplete_words.begin(),autocomplete_words.end());

    // for(int i=0;i<autocomplete_words.size();i++){
    //     cout << autocomplete_words[i] << endl;
    // }
}

#endif