#ifndef AUTO_DIR
#define AUTO_DIR
#include <iostream>
#include <sys/utsname.h>
#include <cstring>
#include <vector>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <algorithm>
// #include "autocomplete.h"

using namespace std;

vector<string> dir_words;
bool match_dir(string a,string target){
    if(a.size() < target.size())return false;
    for(int i=0;i<target.size();i++){
        if(a[i] == target[i])continue;
        else return false;
    }
    return true;
}
string search_dir(vector<string>autocomplete_words,string target){
    for(int i=0;i<autocomplete_words.size();i++){
        if(match_dir(autocomplete_words[i],target))return autocomplete_words[i];
    }
    return "";
}
void auto_dir(){
    char path_file[100];
    getcwd(path_file,100);
    DIR* dir = opendir(path_file);
    if(!dir){
        perror("cannot find dir");
    }
    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        string name(entry->d_name);
        
        // if hidden (starts with .) and -a not set, skip
        if (name[0] == '.')continue;
        else {
            dir_words.push_back(name);
        }
    }      

        
}
#endif